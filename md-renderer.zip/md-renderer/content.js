// MD Renderer — content script
// Détecte automatiquement qu'un fichier Markdown est affiché par Chrome,
// le transforme en document formaté, et permet de l'éditer puis de l'enregistrer.
//
// Deux modes d'entrée :
//  • automatique : déclaré dans le manifest sur les URL se terminant par .md & co.
//    Le rendu ne s'applique que si la page est bien un dump de texte brut
//    (Chrome affiche alors le fichier dans un unique <pre>), jamais sur une vraie
//    page HTML dont l'URL finirait par .md (ex. github.com/…/README.md).
//  • manuel : injecté par le clic sur l'icône. Là, l'intention est explicite,
//    donc on tente le rendu même si la page n'est pas un simple <pre>.

(function () {
  "use strict";

  // Déjà présent dans cette page ? Le second passage sert juste à basculer.
  if (window.__mdRenderer) {
    window.__mdRenderer.toggle();
    return;
  }

  const MANUAL = window.__mdRendererManual === true;
  const MD_URL = /\.(md|markdown|mdown|mkd|mdx)(?:[?#]|$)/i;
  const CLOAK_ID = "md-renderer-cloak";
  const CLOAK_TIMEOUT = 3000; // filet de sécurité : jamais de page blanche bloquée

  let rawText = "";
  let docTitle = "Markdown Document";
  let isRendered = false;
  let isEditing = false;
  let fileHandle = null;
  let article = null;
  let toolbar = null;
  let editBtn = null;
  let saveBtn = null;
  let cloakTimer = null;

  const api = {
    toggle() {
      if (isRendered) revert();
      else render();
    },
    render,
    revert,
    get isRendered() {
      return isRendered;
    },
  };
  window.__mdRenderer = api;

  // Le clic sur l'icône passe par là (voir background.js).
  try {
    chrome.runtime.onMessage.addListener((msg, _sender, respond) => {
      if (msg && msg.type === "md-renderer-toggle") {
        api.toggle();
        respond({ rendered: isRendered });
      }
      return false;
    });
  } catch (_) {
    // Contexte d'extension indisponible : le rendu automatique fonctionne quand même.
  }

  boot();

  // ══════════════════════════════════════════════
  // DÉMARRAGE
  // ══════════════════════════════════════════════

  function boot() {
    if (document.readyState === "loading") {
      // On masque le texte brut le temps du rendu pour éviter le flash.
      if (!MANUAL && MD_URL.test(location.href)) applyCloak();
      document.addEventListener("DOMContentLoaded", start, { once: true });
      window.addEventListener("load", start, { once: true }); // secours
    } else {
      start();
    }
  }

  function start() {
    removeCloak();
    if (isRendered) return;
    const source = extractSource();
    if (source === null) {
      if (MANUAL) console.warn("MD Renderer : aucun texte exploitable sur cette page.");
      return;
    }
    rawText = source;
    render();
  }

  function applyCloak() {
    if (document.getElementById(CLOAK_ID)) return;
    const style = document.createElement("style");
    style.id = CLOAK_ID;
    style.textContent = "html{visibility:hidden!important}";
    (document.head || document.documentElement).appendChild(style);
    cloakTimer = setTimeout(removeCloak, CLOAK_TIMEOUT);
  }

  function removeCloak() {
    if (cloakTimer) {
      clearTimeout(cloakTimer);
      cloakTimer = null;
    }
    const style = document.getElementById(CLOAK_ID);
    if (style) style.remove();
  }

  // Chrome affiche un fichier texte sous la forme <body><pre>…</pre></body>.
  // C'est la signature sur laquelle on s'appuie, indépendamment du type MIME
  // (qui varie selon la plateforme pour l'extension .md).
  function extractSource() {
    const body = document.body;
    if (!body) return null;

    const elements = Array.from(body.children).filter(
      (el) => el.tagName !== "SCRIPT" && el.tagName !== "STYLE" && el.tagName !== "LINK"
    );
    const isPlainTextDump =
      elements.length === 1 && elements[0].tagName === "PRE" && !document.querySelector("link[rel~='stylesheet']");

    if (isPlainTextDump) return elements[0].textContent;
    if (!MANUAL) return null; // on ne touche pas à une vraie page HTML

    const pre = body.querySelector("pre");
    const text = pre ? pre.textContent : body.innerText;
    return text && text.trim() ? text : null;
  }

  // ══════════════════════════════════════════════
  // RENDU
  // ══════════════════════════════════════════════

  function render() {
    if (isRendered) return;

    if (!rawText) {
      const source = extractSource();
      if (!source) return;
      rawText = source;
    }

    if (typeof marked === "undefined") {
      console.error("MD Renderer : marked.js n'est pas chargé, rendu annulé.");
      return;
    }

    marked.setOptions({ breaks: true, gfm: true });
    const htmlContent = marked.parse(rawText);

    const titleMatch = rawText.match(/^#\s+(.+)$/m);
    docTitle = titleMatch ? titleMatch[1].trim() : fileNameFromUrl() || "Markdown Document";

    document.body.innerHTML = "";
    document.body.className = "md-renderer-body";
    document.body.dataset.mdRendered = "true";

    article = document.createElement("article");
    article.className = "md-renderer-content";
    article.innerHTML = htmlContent;

    toolbar = buildToolbar();

    const wrapper = document.createElement("div");
    wrapper.className = "md-renderer-wrapper";
    wrapper.appendChild(article);

    document.body.appendChild(toolbar);
    document.body.appendChild(wrapper);
    document.body.appendChild(buildBottomBar());

    document.title = docTitle;
    postProcessArticle(article);

    isRendered = true;
    isEditing = false;
  }

  function revert() {
    if (!isRendered) return;
    if (isEditing) syncRawFromArticle(); // ne jamais perdre une édition en cours

    isEditing = false;
    isRendered = false;
    article = null;
    toolbar = null;

    document.body.innerHTML = "";
    document.body.className = "";
    document.body.removeAttribute("style");
    document.body.removeAttribute("data-md-rendered");
    document.title = fileNameFromUrl() || document.title;

    const pre = document.createElement("pre");
    pre.className = "md-renderer-raw";
    pre.textContent = rawText;
    document.body.appendChild(pre);

    const bar = document.createElement("div");
    bar.className = "md-renderer-bottombar";
    const back = document.createElement("button");
    back.className = "md-renderer-btn";
    back.textContent = "MD";
    back.title = "Revenir au document formaté";
    back.addEventListener("click", () => render());
    bar.appendChild(back);
    document.body.appendChild(bar);
  }

  function fileNameFromUrl() {
    try {
      const path = decodeURIComponent(new URL(location.href).pathname);
      return path.split("/").filter(Boolean).pop() || "";
    } catch (_) {
      return "";
    }
  }

  // ══════════════════════════════════════════════
  // INTERFACE
  // ══════════════════════════════════════════════

  function buildToolbar() {
    const el = document.createElement("div");
    el.className = "md-renderer-toolbar";
    el.innerHTML = `
      <div class="md-toolbar-group">
        <button data-cmd="bold" title="Gras (Ctrl+B)"><strong>B</strong></button>
        <button data-cmd="italic" title="Italique (Ctrl+I)"><em>I</em></button>
        <button data-cmd="strikethrough" title="Barré">
          <span style="text-decoration:line-through">S</span>
        </button>
        <button data-cmd="code" title="Code inline">&lt;/&gt;</button>
      </div>
      <div class="md-toolbar-separator"></div>
      <div class="md-toolbar-group">
        <button data-cmd="h1" title="Titre 1">H1</button>
        <button data-cmd="h2" title="Titre 2">H2</button>
        <button data-cmd="h3" title="Titre 3">H3</button>
      </div>
      <div class="md-toolbar-separator"></div>
      <div class="md-toolbar-group">
        <button data-cmd="ul" title="Liste à puces">&#8226; List</button>
        <button data-cmd="ol" title="Liste numérotée">1. List</button>
        <button data-cmd="blockquote" title="Citation">&ldquo; Quote</button>
      </div>
      <div class="md-toolbar-separator"></div>
      <div class="md-toolbar-group">
        <button data-cmd="link" title="Lien">&#128279; Link</button>
        <button data-cmd="hr" title="Ligne horizontale">&mdash; HR</button>
      </div>
    `;
    el.addEventListener("click", onToolbarClick);
    return el;
  }

  function buildBottomBar() {
    const bar = document.createElement("div");
    bar.className = "md-renderer-bottombar";

    editBtn = document.createElement("button");
    editBtn.className = "md-renderer-btn md-renderer-btn-edit";
    editBtn.textContent = "EDIT";
    editBtn.title = "Activer le mode édition";
    editBtn.addEventListener("click", () => (isEditing ? exitEditMode() : enterEditMode()));

    saveBtn = document.createElement("button");
    saveBtn.className = "md-renderer-btn md-renderer-btn-save";
    saveBtn.textContent = "SAVE";
    saveBtn.title = "Sauvegarder en Markdown";
    saveBtn.style.display = "none";
    saveBtn.addEventListener("click", saveMarkdown);

    const rawBtn = document.createElement("button");
    rawBtn.className = "md-renderer-btn md-renderer-btn-raw";
    rawBtn.textContent = "RAW";
    rawBtn.title = "Afficher le Markdown brut";
    rawBtn.addEventListener("click", revert);

    bar.appendChild(editBtn);
    bar.appendChild(saveBtn);
    bar.appendChild(rawBtn);
    return bar;
  }

  function onToolbarClick(e) {
    const btn = e.target.closest("button[data-cmd]");
    if (!btn || !isEditing) return;
    e.preventDefault();

    switch (btn.dataset.cmd) {
      case "bold":
        document.execCommand("bold");
        break;
      case "italic":
        document.execCommand("italic");
        break;
      case "strikethrough":
        document.execCommand("strikeThrough");
        break;
      case "code":
        wrapSelectionWith("code");
        break;
      case "h1":
      case "h2":
      case "h3":
        document.execCommand("formatBlock", false, btn.dataset.cmd);
        break;
      case "ul":
        document.execCommand("insertUnorderedList");
        break;
      case "ol":
        document.execCommand("insertOrderedList");
        break;
      case "blockquote":
        document.execCommand("formatBlock", false, "blockquote");
        break;
      case "link":
        insertLink();
        break;
      case "hr":
        document.execCommand("insertHorizontalRule");
        break;
    }

    if (article) article.focus();
  }

  // Raccourcis clavier : posés une seule fois, ils ne font rien hors édition.
  document.addEventListener("keydown", (e) => {
    if (!isEditing) return;
    const mod = e.ctrlKey || e.metaKey;
    if (!mod) return;

    if (e.key === "b") {
      e.preventDefault();
      document.execCommand("bold");
    } else if (e.key === "i") {
      e.preventDefault();
      document.execCommand("italic");
    } else if (e.key === "s") {
      e.preventDefault();
      saveMarkdown();
    }
  });

  // ══════════════════════════════════════════════
  // ÉDITION
  // ══════════════════════════════════════════════

  function enterEditMode() {
    if (!article) return;
    isEditing = true;
    article.contentEditable = "true";
    article.classList.add("md-editing");
    toolbar.classList.add("md-toolbar-visible");
    editBtn.textContent = "DONE";
    editBtn.classList.add("md-renderer-btn-active");
    saveBtn.style.display = "";
    article.focus();
  }

  function exitEditMode() {
    if (!article) return;
    isEditing = false;
    article.contentEditable = "false";
    article.classList.remove("md-editing");
    toolbar.classList.remove("md-toolbar-visible");
    editBtn.textContent = "EDIT";
    editBtn.classList.remove("md-renderer-btn-active");
    saveBtn.style.display = "none";
    syncRawFromArticle();
    postProcessArticle(article);
  }

  function wrapSelectionWith(tag) {
    const sel = window.getSelection();
    if (!sel.rangeCount) return;
    const range = sel.getRangeAt(0);
    const el = document.createElement(tag);
    try {
      range.surroundContents(el);
    } catch (_) {
      return; // sélection à cheval sur plusieurs blocs : on ne casse rien
    }
    sel.removeAllRanges();
    const newRange = document.createRange();
    newRange.selectNodeContents(el);
    sel.addRange(newRange);
  }

  function insertLink() {
    const sel = window.getSelection();
    const text = sel.toString() || "lien";
    const url = prompt("URL du lien :", "https://");
    if (!url) return;
    const a = document.createElement("a");
    a.href = url;
    a.textContent = text;
    a.setAttribute("target", "_blank");
    a.setAttribute("rel", "noopener noreferrer");
    if (sel.rangeCount) {
      const range = sel.getRangeAt(0);
      range.deleteContents();
      range.insertNode(a);
    }
  }

  // ══════════════════════════════════════════════
  // MARKDOWN → FICHIER
  // ══════════════════════════════════════════════

  function toMarkdown() {
    if (typeof TurndownService === "undefined") return null;

    const turndown = new TurndownService({
      headingStyle: "atx",
      hr: "---",
      bulletListMarker: "-",
      codeBlockStyle: "fenced",
      fence: "```",
      emDelimiter: "*",
      strongDelimiter: "**",
    });

    turndown.addRule("strikethrough", {
      filter: ["del", "s"],
      replacement: (content) => "~~" + content + "~~",
    });

    return turndown.turndown(article.innerHTML);
  }

  function syncRawFromArticle() {
    if (!article) return;
    const markdown = toMarkdown();
    if (markdown !== null) rawText = markdown;
  }

  async function saveMarkdown() {
    if (!article) return;

    const markdown = toMarkdown();
    if (markdown === null) {
      console.error("MD Renderer : Turndown.js n'est pas chargé.");
      showNotification("Impossible de convertir : Turndown.js manquant.");
      return;
    }
    rawText = markdown;

    const suggested = (fileNameFromUrl() || docTitle.replace(/[^\w\s-]/g, "").trim() || "document")
      .replace(/\.(md|markdown|mdown|mkd|mdx)$/i, "") + ".md";

    if ("showSaveFilePicker" in window) {
      try {
        if (!fileHandle) {
          fileHandle = await window.showSaveFilePicker({
            suggestedName: suggested,
            types: [{ description: "Markdown", accept: { "text/markdown": [".md"] } }],
          });
        }
        const writable = await fileHandle.createWritable();
        await writable.write(markdown);
        await writable.close();
        showNotification("Fichier sauvegardé !");
        return;
      } catch (err) {
        if (err && err.name === "AbortError") return; // annulé par l'utilisateur
        console.warn("MD Renderer : enregistrement direct impossible, passage au téléchargement.", err);
      }
    }

    const blob = new Blob([markdown], { type: "text/markdown;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = suggested;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
    showNotification("Fichier téléchargé !");
  }

  function showNotification(message) {
    const notif = document.createElement("div");
    notif.className = "md-renderer-notification";
    notif.textContent = message;
    document.body.appendChild(notif);
    requestAnimationFrame(() => notif.classList.add("md-notif-visible"));
    setTimeout(() => {
      notif.classList.remove("md-notif-visible");
      setTimeout(() => notif.remove(), 300);
    }, 2000);
  }

  function postProcessArticle(el) {
    el.querySelectorAll("pre code").forEach((block) => {
      const langClass = Array.from(block.classList).find((c) => c.startsWith("language-"));
      if (langClass) {
        block.parentElement.dataset.language = langClass.replace("language-", "");
      }
    });

    el.querySelectorAll('a[href^="http"]').forEach((link) => {
      link.setAttribute("target", "_blank");
      link.setAttribute("rel", "noopener noreferrer");
    });

    el.querySelectorAll("h1, h2, h3, h4, h5, h6").forEach((heading) => {
      heading.id = heading.textContent
        .toLowerCase()
        .replace(/[^\w\s-]/g, "")
        .trim()
        .replace(/\s+/g, "-");
    });
  }
})();
