# MD Renderer — Extension Chrome

Extension Chrome minimaliste qui transforme les fichiers `.md` ouverts dans Chrome
en documents élégamment formatés — **automatiquement, sans rien cliquer**.

## Installation

1. Ouvrir `chrome://extensions/` dans Chrome
2. Activer le **Mode développeur** (toggle en haut à droite)
3. Cliquer **Charger l'extension non empaquetée** et sélectionner ce dossier
4. Sur la carte MD Renderer, cliquer **Détails** puis activer
   **« Autoriser l'accès aux URL de fichier »** — sans cela Chrome interdit à
   l'extension de lire vos fichiers locaux, et les `.md` de votre disque
   resteront en texte brut. C'est la seule étape manuelle, et elle ne se fait
   qu'une fois.

Si cette autorisation manque, l'extension le signale d'elle-même : un **!** rouge
apparaît sur son icône, et une page d'explication (`setup.html`) s'ouvre à
l'installation avec la marche à suivre et un voyant qui passe au vert dès que
c'est réglé.

## Utilisation

Ouvrir un fichier `.md` dans Chrome (glisser-déposer, `Fichier > Ouvrir`, ou une
URL). Il s'affiche mis en forme. C'est tout.

En bas à droite :

| Bouton | Effet |
|--------|-------|
| **EDIT** | Passe le document en édition WYSIWYG (barre d'outils en haut) |
| **SAVE** | Réécrit le Markdown et l'enregistre (ou le télécharge) |
| **RAW** | Revient au texte brut ; le bouton **MD** ramène au rendu |

Un clic sur l'icône de l'extension bascule aussi entre rendu et brut, et force le
rendu sur les pages où il ne se déclenche pas tout seul.

## Où le rendu s'applique

- Fichiers locaux : `file:///…/*.md`, `.markdown`, `.mdown`, `.mkd`, `.mdx`
- Markdown servi par le web : `http(s)://…/*.md` & co. (GitHub raw, gists…)

Le rendu automatique ne se déclenche que si la page est réellement un fichier
texte affiché par Chrome (un unique `<pre>`). Une vraie page HTML dont l'URL finit
par `.md` — `github.com/user/repo/blob/main/README.md`, par exemple — n'est jamais
touchée. Sur ces pages, le clic sur l'icône force quand même le rendu.

Pour éviter de voir passer le texte brut avant la mise en forme, l'extension
masque brièvement la page pendant le rendu, avec une sécurité de 3 s qui la
réaffiche quoi qu'il arrive.

## Structure

```
md-renderer-extension/
├── manifest.json      # Manifest V3 — déclare l'injection automatique
├── background.js      # Service worker : bascule au clic + alerte accès fichiers
├── content.js         # Détection, rendu MD → HTML, édition, sauvegarde
├── styles.css         # Styles du rendu et de la vue brute
├── setup.html/.js     # Page d'explication de l'autorisation fichiers locaux
├── marked.min.js      # Parser Markdown (bundled, ~40 Ko)
├── turndown.min.js    # HTML → Markdown pour la sauvegarde (bundled, ~21 Ko)
├── icons/
└── README.md
```

Aucune dépendance externe, aucun appel réseau : tout est embarqué.

## Dépendances

- [marked.js](https://github.com/markedjs/marked) — Markdown → HTML
- [Turndown](https://github.com/mixmark-io/turndown) — HTML → Markdown
