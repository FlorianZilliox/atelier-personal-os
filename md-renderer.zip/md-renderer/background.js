// MD Renderer — service worker
// Le rendu est automatique (content script déclaré dans le manifest).
// Ce worker sert à deux choses :
//   1. le clic sur l'icône bascule rendu <-> brut sur la page courante ;
//   2. il prévient l'utilisateur si l'accès aux fichiers locaux n'est pas autorisé,
//      seule condition non automatisable pour que les fichiers file:// soient rendus.

const SETUP_PAGE = "setup.html";

// ── 1. Clic sur l'icône ──────────────────────────────────────────────

chrome.action.onClicked.addListener(async (tab) => {
  if (!tab || typeof tab.id !== "number") return;

  // Cas normal : le content script est déjà là, on lui demande de basculer.
  try {
    const reply = await chrome.tabs.sendMessage(tab.id, { type: "md-renderer-toggle" });
    if (reply) return;
  } catch (_) {
    // Pas de content script sur cette page (extension non prévue pour cette URL) :
    // on l'injecte à la demande, le clic vaut alors accord explicite.
  }

  try {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => {
        window.__mdRendererManual = true;
      },
    });
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ["marked.min.js", "turndown.min.js", "content.js"],
    });
    await chrome.scripting.insertCSS({
      target: { tabId: tab.id },
      files: ["styles.css"],
    });
  } catch (err) {
    console.error("MD Renderer : injection impossible sur cette page.", err);
    await explainFileAccessIfNeeded(true);
  }
});

// ── 2. Accès aux fichiers locaux ─────────────────────────────────────

chrome.runtime.onInstalled.addListener(async ({ reason }) => {
  const ok = await hasFileAccess();
  await updateBadge(ok);
  if (!ok && (reason === "install" || reason === "update")) {
    chrome.tabs.create({ url: chrome.runtime.getURL(SETUP_PAGE) });
  }
});

chrome.runtime.onStartup.addListener(async () => {
  await updateBadge(await hasFileAccess());
});

// Le réglage peut être changé à tout moment dans chrome://extensions :
// on revérifie à chaque chargement de page (test local, aucun coût réseau).
chrome.tabs.onUpdated.addListener(async (_tabId, info) => {
  if (info.status !== "complete") return;
  await updateBadge(await hasFileAccess());
});

async function hasFileAccess() {
  try {
    return await chrome.extension.isAllowedFileSchemeAccess();
  } catch (_) {
    return true; // API indisponible : on n'affole pas l'utilisateur pour rien.
  }
}

async function updateBadge(ok) {
  try {
    await chrome.action.setBadgeText({ text: ok ? "" : "!" });
    await chrome.action.setBadgeBackgroundColor({ color: "#b3261e" });
    await chrome.action.setTitle({
      title: ok
        ? "MD Renderer — basculer rendu / brut"
        : "MD Renderer : accès aux fichiers locaux désactivé — cliquez pour voir comment l'activer",
    });
  } catch (_) {}
}

async function explainFileAccessIfNeeded(openPage) {
  const ok = await hasFileAccess();
  await updateBadge(ok);
  if (!ok && openPage) {
    chrome.tabs.create({ url: chrome.runtime.getURL(SETUP_PAGE) });
  }
}
