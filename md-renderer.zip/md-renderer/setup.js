// Page d'explication : vérifie en direct si l'accès aux fichiers locaux est accordé.

const statusEl = document.getElementById("status");
const textEl = document.getElementById("status-text");

document.getElementById("copy").addEventListener("click", async (e) => {
  try {
    await navigator.clipboard.writeText("chrome://extensions/");
    e.target.textContent = "Adresse copiée ✓";
    setTimeout(() => (e.target.textContent = "Copier l'adresse"), 2000);
  } catch (_) {
    e.target.textContent = "Copie refusée — sélectionnez l'adresse à la main";
  }
});

async function check() {
  let allowed;
  try {
    allowed = await chrome.extension.isAllowedFileSchemeAccess();
  } catch (_) {
    textEl.textContent = "État inconnu : vérifiez le réglage dans chrome://extensions/";
    statusEl.dataset.state = "unknown";
    return;
  }

  statusEl.dataset.state = allowed ? "ok" : "ko";
  textEl.textContent = allowed
    ? "C'est activé — vos fichiers .md locaux s'affichent maintenant tout seuls."
    : "Pour l'instant désactivé — suivez les 4 étapes ci-dessous.";
}

check();
setInterval(check, 1000);
